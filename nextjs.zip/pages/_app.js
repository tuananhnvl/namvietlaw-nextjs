import '../styles/globals.css'


// eslint-disable-next-line
import "swiper/css/bundle";
function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
