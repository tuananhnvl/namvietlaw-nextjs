/* GET template*/
import React from 'react';

import NavBar from '../component/Navbar'

class NewFeeds extends React.Component {
    render() {
        return (
            <>
            <NavBar />
            <p>HEELO NEWFRREDS</p>
            </>
           
        )
    }
}

export default NewFeeds
